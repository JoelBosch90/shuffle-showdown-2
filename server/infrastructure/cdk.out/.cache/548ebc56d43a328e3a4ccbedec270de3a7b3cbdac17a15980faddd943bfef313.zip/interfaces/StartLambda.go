package interfaces

type StartLambda func(handler interface{})
